﻿using Prova01.Class.Exercicio02;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova01.Class.Exercicio01
{
    public class Pessoa
    {
        public string Nome = "Marcelo";
        public int Idade = 20;


        public void Cumprimentar()
        {
            Console.WriteLine($"Olá! Meu nome é {Nome} e tenho {Idade} anos.");

        }

        public class Aluno : Pessoa
        {
            public string Nome = "Isadora";
            public int Idade = 21;

            public void CumprimentarAluno()
            {
                Console.WriteLine($"Olá! Meu nome é {Nome} e tenho {Idade} anos.");
            }

            public void IrParaEscola()
            {
                Console.WriteLine("Estou indo para escola ;)");

            }


        }

        public class Professor : Pessoa
        {
            public string Nome = "Luiz";
            public int Idade = 30;

            public void CumprimentarProfessor()
            {
                Console.WriteLine($"Olá! Meu nome é {Nome} e tenho {Idade} anos.");

            }

            public void Explicar()
            {
                Console.WriteLine("Hoje vou explicar sobre orientação a objeto:");
                Console.WriteLine("------------------------------------------------");
                Console.WriteLine("A orientação a objetos é um paradigma de programação que se baseia no conceito de 'objetos'.");
                Console.WriteLine("Um objeto é uma instância de uma classe que possui características (atributos) e comportamentos (métodos).");
                Console.WriteLine("Isso torna o código mais modular, reutilizável e fácil de entender.");
                Console.WriteLine("Na orientação a objetos, trabalhamos com conceitos como classes, objetos, atributos, métodos, encapsulamento, herança e polimorfismo.");
            }
        }
    }
}


