﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Prova01.Class.Exercicio02
{
    public class Habitacao
    {
        public double Area = 123;
        public Porta Porta = new Porta();

        public Habitacao()
        {
        }

        public Habitacao(double area, Porta porta)
        {
            Area = area;
            Porta = porta;
        }

        public void Mostrar()
        {
            Console.WriteLine($"Eu sou uma habitação, minha área é {Area}m2, e a cor da minha porta é {Porta.Cor}");
        }

        public class Apartamento : Habitacao
        {
            public double Area = 50;
        }
    }
}

