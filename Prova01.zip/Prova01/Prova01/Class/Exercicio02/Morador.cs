﻿using Prova01.Class.Exercicio01;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova01.Class.Exercicio02
{
    public class Morador : Pessoa
    {
        public Habitacao Habitacao = new Habitacao();

        public void Mostrar()
        {
            base.Cumprimentar();
            Habitacao.Mostrar();
        }

        public class CriarMorador : Habitacao
        {

            public Apartamento Apartamento = new Apartamento();

            public string Nome = "Felipe";
            public int Idade = 21;

            public CriarMorador()
            {
            }

            public CriarMorador(string nome, int idade)
            {
                Nome = nome;
                Idade = idade;
            }

            public void CriarPessoa()
            {

                Console.Clear();

                Console.WriteLine($"Olá, meu nome é {Nome} e eu tenho {Idade} anos.");
                Console.WriteLine($"Eu moro no apartamento 25 e ele tem {Apartamento.Area}m2.");

            }
        }

    }
}
