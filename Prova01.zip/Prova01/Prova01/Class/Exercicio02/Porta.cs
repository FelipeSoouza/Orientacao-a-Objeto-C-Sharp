﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Prova01.Class.Exercicio02
{
    public class Porta
    {
        public string Cor { get; set; }

        public Porta()
        {
            this.Cor = "Marrom";
        }

        public void MostrarCor()
        {
            Console.WriteLine($"Eu sou uma porta e minha cor é {Cor}.");
        }
    }

}
