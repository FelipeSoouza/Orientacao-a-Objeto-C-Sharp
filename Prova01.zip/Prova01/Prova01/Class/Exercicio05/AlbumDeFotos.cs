﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova01.Class.Exercicio05
{
    public class AlbumDeFotos
    {
     
        public int NumeroTotalDePaginas { get; private set; }

        public int NumeroTotalDeFotos => NumeroTotalDePaginas * 2;

        private int _numeroDeFotos;
        public int NumeroDeFotos
        {
            get { return _numeroDeFotos; }
            set
            {
                if (value <= NumeroTotalDeFotos)
                {
                    _numeroDeFotos = value;
                }
                else
                {
                    Console.WriteLine("Erro: número de fotos excede o limite do álbum.");
                }
            }
        }

        
        public AlbumDeFotos(int numeroTotalDePaginas)
        {
            NumeroTotalDePaginas = numeroTotalDePaginas;
        }

        public AlbumDeFotos()
        {
        }

        public void EscolherNumeroDePaginas()
        {
            AlbumDeFotos album = new AlbumDeFotos(10);

            Console.WriteLine("Teste com número de fotos excedendo o limite.");
            album.NumeroDeFotos = 25;

            Console.WriteLine("\nTeste com número de fotos dentro do limite.");
            album.NumeroDeFotos = 15;

            
        }
    }
}
