﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova01.Class.Exercicio03
{
    public class Retangulo
    {
        public double Altura { get; set; }
        public double Largura { get; set; }


        public Retangulo(double altura, double largura)
        {
            Altura = altura;
            Largura = largura;
        }

        public void MostrarRetangulo()
        {
            Console.WriteLine("Altura: " + Altura);
            Console.WriteLine("Largura: " + Largura);
        }
    }
}
