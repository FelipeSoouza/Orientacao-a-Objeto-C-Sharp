﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova01.Class.Exercicio04
{
    public class Ponto3D
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }

        public Ponto3D(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }


        public void Mostrar()
        {
            Console.WriteLine($"({X}, {Y}, {Z})");
        }

        public void MoverPara(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }


        public double Distancia(Ponto3D p2)
        {
            double disX = X - p2.X;
            double disY = Y - p2.Y;
            double disZ = Z - p2.Z;

            return Math.Sqrt(disX * disX + disY * disY + disZ * disZ);
        }
    }
}
