﻿using System.Security.Cryptography.X509Certificates;
using System.Threading.Channels;
using Prova01.Class.Exercicio01;
using Prova01.Class.Exercicio02;
using Prova01.Class.Exercicio03;
using Prova01.Class.Exercicio04;
using Prova01.Class.Exercicio05;

namespace Prova01
{
    public class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                
                Console.WriteLine("Olá, bem vindo a prova do professor Luiz.Fizemos 5 exercicios.");
                Console.WriteLine("Escolha qual exercicio deseja ver:");
                Console.WriteLine("1(Exercicio 1)");
                Console.WriteLine("2(Exercicio 2)");
                Console.WriteLine("3(Exercicio 3)");
                Console.WriteLine("4(Exercicio 4)");
                Console.WriteLine("5(Exercicio 5)");
                Console.WriteLine("6(Sair)");
                Console.WriteLine("---------------------------------");
                int escolha = int.Parse(Console.ReadLine());

                switch (escolha)
                {
                    case 1:
                        Exercicio1();
                        break;
                    case 2:
                        Exercicio2();
                        break;
                    case 3:
                        Exercicio3();
                        break;
                    case 4:
                        Exercicio4();
                        break;
                    case 5:
                        Exercicio5();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Escolha uma opção válida.");
                        break;
                }
            }
            

        }

        static void Exercicio1()
        {
            Console.WriteLine("Escolha com quem deseja falar:");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("1 (Marcelo)");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("2 (Aluno)");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("3 (Professor)");
            Console.WriteLine("----------------------------------------");
            int escolha = int.Parse(Console.ReadLine());
            Console.Clear();

            Pessoa marcelo = new Pessoa();
            Pessoa.Aluno aluno = new Pessoa.Aluno();
            Pessoa.Professor professor = new Pessoa.Professor();

            if (escolha == 1)
            {
                marcelo.Cumprimentar();
            }

            else if (escolha == 2)
            {
                aluno.CumprimentarAluno();

                Console.WriteLine("Ir para escola 1 (SIM) ou 2 (NÃO)");
                int escolhaAluno = int.Parse(Console.ReadLine());
                Console.Clear();

                if (escolhaAluno == 1)
                {
                    aluno.IrParaEscola();
                }
                else
                {
                    Console.WriteLine("Então vou ficar jogando em casa");
                }
            }
            else if (escolha == 3)
            {
                professor.CumprimentarProfessor();

                professor.Explicar();
            }
            else
            {
                Console.WriteLine("Escolha uma opção válida.");
            }
        }
        
        static void Exercicio2()
        {
            Porta porta = new Porta();
            Habitacao habitacao = new Habitacao();
            Morador morador = new Morador();
            Morador.CriarMorador pessoa = new Morador.CriarMorador();


            Console.WriteLine("Escolha as opções:");
            Console.WriteLine("----------------------------------");
            Console.WriteLine("1 = (Falar com a Porta.)");
            Console.WriteLine("2 = (Falar com a Habitação.)");
            Console.WriteLine("3 = (Falar com um morador.)");
            Console.WriteLine("4 = (Criar uma pessoa.)");
            Console.WriteLine("----------------------------------");

            int escolha = int.Parse(Console.ReadLine());
            Console.Clear();

            if (escolha == 1)
            {
                Console.Clear();
                porta.MostrarCor();
            }
            else if (escolha == 2)
            {
                Console.WriteLine("Quantos metros vai ter sua habitação?");
                habitacao.Area = double.Parse(Console.ReadLine());
                Console.Clear();

                habitacao.Mostrar();

            }
            else if(escolha == 3)
            {
                morador.Mostrar();

            }
            else if(escolha == 4)
            {
                pessoa.CriarPessoa();
            }
            else
            {
                Console.WriteLine("Escolha uma opção válida.");
            }
        }
       
        static void Exercicio3()
        {
            Retangulo[] retangulos = new Retangulo[10];

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Informe as dimensões do retângulo {i + 1}:");
                Console.Write("Altura: ");
                double altura = Convert.ToDouble(Console.ReadLine());
                Console.Write("Largura: ");
                double largura = Convert.ToDouble(Console.ReadLine());

                Console.Clear();

                retangulos[i] = new Retangulo(altura, largura);
            }

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"\nRetângulo {i + 1}:");
                retangulos[i].MostrarRetangulo();
            }
        }
       
        static void Exercicio4()
        {
            Console.Write("Quantidade de pontos: ");
            int N = int.Parse(Console.ReadLine());

            
            Ponto3D[] pontos = new Ponto3D[N];

           
            for (int i = 0; i < N; i++)
            {
                Console.WriteLine($"\nCoordenadas do ponto {i + 1}:");
                Console.Write("X: ");
                double x = double.Parse(Console.ReadLine());
                Console.Write("Y: ");
                double y = double.Parse(Console.ReadLine());
                Console.Write("Z: ");
                double z = double.Parse(Console.ReadLine());

                pontos[i] = new Ponto3D(x, y, z);
            }

            Ponto3D primeiroPonto = pontos[0];
            Console.WriteLine("\nDistâncias em relação ao primeiro ponto:");
            for (int i = 1; i < N; i++)
            {
                double distancia = primeiroPonto.Distancia(pontos[i]);
                Console.WriteLine($"Ponto {i + 1}: {distancia}");
            }
        }
        
        static void Exercicio5()
        {
            
            AlbumDeFotos album = new AlbumDeFotos();

            album.EscolherNumeroDePaginas();

        }

    }
}